// Мини-хелпер для переводов: принимает lang и возвращает нужную строку
import type { Lang } from './types';

export function tr(lang: Lang, ru: string, en: string): string {
  return lang === 'en' ? en : ru;
}

// Статус-лейблы для финального скора
export function getScoreStatus(total: number, lang: Lang): { status: 'critical' | 'warning' | 'good' | 'excellent'; label: string } {
  if (total <= 30) {
    return { status: 'critical', label: tr(lang, 'Критично', 'Critical') };
  }
  if (total <= 50) {
    return { status: 'warning', label: tr(lang, 'Требует внимания', 'Needs attention') };
  }
  if (total <= 70) {
    return { status: 'good', label: tr(lang, 'Есть потенциал', 'Has potential') };
  }
  return { status: 'excellent', label: tr(lang, 'Хорошо', 'Good') };
}

// Конвертация скора проверки в статус pass/warn/fail
export function toCheckStatus(score: number, maxScore: number): 'pass' | 'warn' | 'fail' {
  if (maxScore === 0) return 'pass';
  const ratio = score / maxScore;
  if (ratio >= 0.7) return 'pass';
  if (ratio > 0) return 'warn';
  return 'fail';
}
