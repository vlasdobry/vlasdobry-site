// Агрегатор: запускает все 7 проверок и возвращает финальный GeoScore

import type { GeoScore, GeoScoreInput, GeoScoreOptions, CheckResult, Issue, CheckId } from './types.js';
import { DEFAULT_BOTS, DEFAULT_WEIGHTS } from './types.js';
import { getScoreStatus } from './i18n.js';
import { checkLlmFiles } from './checks/llm-files.js';
import { checkSchemaOrg } from './checks/schema-org.js';
import { checkFaqQa } from './checks/faq-qa.js';
import { checkEeat } from './checks/eeat.js';
import { checkCitability } from './checks/citability.js';
import { checkAiAccess } from './checks/ai-access.js';
import { checkRenderedVsSource } from './checks/rendered-vs-source.js';

/**
 * Извлекает @type из HTML один раз, чтобы не парсить JSON-LD дважды в faq-qa и schema-org.
 */
function extractJsonLdTypes(html: string): string[] {
  const pattern = /<script[^>]*type=["']application\/ld\+json["'][^>]*>([\s\S]*?)<\/script>/gi;
  const types = new Set<string>();
  let match: RegExpExecArray | null;

  while ((match = pattern.exec(html)) !== null) {
    try {
      const data = JSON.parse(match[1].trim());
      collectTypes(data, types);
    } catch {
      // Невалидный JSON — пропускаем
    }
  }
  return Array.from(types);
}

function collectTypes(data: unknown, types: Set<string>): void {
  if (Array.isArray(data)) {
    for (const item of data) collectTypes(item, types);
    return;
  }
  if (typeof data !== 'object' || data === null) return;
  const obj = data as Record<string, unknown>;
  if (typeof obj['@type'] === 'string') types.add(obj['@type']);
  else if (Array.isArray(obj['@type'])) {
    for (const t of obj['@type']) if (typeof t === 'string') types.add(t);
  }
  for (const key of Object.keys(obj)) {
    if (key === '@type' || key === '@context' || key === '@id') continue;
    const value = obj[key];
    if (typeof value === 'object' && value !== null) collectTypes(value, types);
  }
}

export function calculateGeoScore(
  input: GeoScoreInput,
  options: GeoScoreOptions = {},
): GeoScore {
  const lang = options.lang ?? 'ru';
  const bots = options.bots ?? DEFAULT_BOTS;

  const html = input.homepage.content ?? '';
  const jsonLdTypes = html ? extractJsonLdTypes(html) : [];

  const checks: CheckResult[] = [
    checkLlmFiles(input.llmsTxt, input.llmsFullTxt, lang),
    checkSchemaOrg(html, lang),
    checkFaqQa(html, jsonLdTypes, lang),
    checkEeat(html, lang),
    checkCitability(html, lang),
    checkAiAccess(input.robotsTxt, bots, lang),
    // rendered-vs-source сравнивает post-JS (renderedHtml) с pre-JS (homepage = source)
    // Если renderedHtml не передан — sourceHtml=null → full score (нельзя сравнить).
    checkRenderedVsSource(
      input.renderedHtml ?? html,
      input.renderedHtml ? html : null,
      lang,
    ),
  ];

  const total = checks.reduce((sum, c) => sum + c.score, 0);
  const maxTotal = checks.reduce((sum, c) => sum + c.maxScore, 0);

  const breakdown = checks.reduce((acc, c) => {
    acc[c.id] = c.score;
    return acc;
  }, {} as Record<CheckId, number>);

  // Объединяем и сортируем issues по severity
  const severityOrder: Record<string, number> = {
    critical: 0, warning: 1, info: 2, success: 3,
  };
  const issues: Issue[] = checks
    .flatMap(c => c.issues)
    .sort((a, b) => severityOrder[a.severity] - severityOrder[b.severity]);

  const { status, label } = getScoreStatus(total, lang);

  return {
    total,
    maxTotal,
    status,
    statusLabel: label,
    breakdown,
    checks,
    issues,
  };
}

// Реэкспорт весов для настройки
export { DEFAULT_WEIGHTS };
