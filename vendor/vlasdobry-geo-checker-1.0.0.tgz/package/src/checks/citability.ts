// Citability check (10 баллов) — по методологии Princeton/Georgia Tech (2024).
// AI-системы охотнее цитируют пассажи с:
//  (1) question-based / imperative заголовками,
//  (2) оптимальной длиной параграфов,
//  (3) высокой статистической плотностью,
//  (4) таблицами/списками для структуры.

import type { Issue, CheckResult, Lang } from '../types.js';
import { tr, toCheckStatus } from '../i18n.js';

// Извлекает видимый текст из HTML: убирает script, style, теги, комменты.
// Не идеален, но достаточен для грубой оценки структуры контента.
function extractVisibleText(html: string): string {
  return html
    .replace(/<script\b[^>]*>[\s\S]*?<\/script>/gi, ' ')
    .replace(/<style\b[^>]*>[\s\S]*?<\/style>/gi, ' ')
    .replace(/<noscript\b[^>]*>[\s\S]*?<\/noscript>/gi, ' ')
    .replace(/<!--[\s\S]*?-->/g, ' ')
    .replace(/<[^>]+>/g, ' ')
    .replace(/\s+/g, ' ')
    .trim();
}

// Извлекает H2/H3 заголовки (видимый текст, без тегов).
function extractHeadings(html: string): string[] {
  const matches = html.matchAll(/<h[23]\b[^>]*>([\s\S]*?)<\/h[23]>/gi);
  const result: string[] = [];
  for (const m of matches) {
    const text = m[1].replace(/<[^>]+>/g, '').trim();
    if (text) result.push(text);
  }
  return result;
}

// Извлекает тексты параграфов.
function extractParagraphs(html: string): string[] {
  const matches = html.matchAll(/<p\b[^>]*>([\s\S]*?)<\/p>/gi);
  const result: string[] = [];
  for (const m of matches) {
    const text = m[1].replace(/<[^>]+>/g, '').trim();
    if (text) result.push(text);
  }
  return result;
}

export function checkCitability(html: string, lang: Lang): CheckResult {
  const issues: Issue[] = [];
  let score = 0;
  const signals: string[] = [];

  const headings = extractHeadings(html);
  const paragraphs = extractParagraphs(html);
  const visibleText = extractVisibleText(html);
  const totalWords = visibleText.split(/\s+/).filter(Boolean).length;

  // 1. AI-friendly заголовки (3 балла).
  // AI-модели охотно цитируют два типа заголовков:
  //  (a) вопросительные — «Что такое X?», «How does Y work?» — напрямую отвечают
  //      на поисковые запросы пользователя.
  //  (b) повелительные/инструктивные — «Проверь X», «Configure Y» — используются
  //      AI как шаги внутри how-to ответов.
  //
  // ВАЖНО: JavaScript regex `\b` (word boundary) работает только для ASCII-слов.
  // Между кириллицей и пробелом `\b` не срабатывает, потому что кириллица не в `\w`.
  // Поэтому для RU-паттернов используем negative lookahead `(?![а-яА-Я])` вместо `\b`.
  const questionRu = /^(что|как|зачем|почему|когда|где|какой|сколько|кто|чем|чему|какая|какие|каковы|стоит ли|нужно ли|можно ли)(?![а-яА-Я])/i;
  const questionEn = /^(what|how|why|when|where|which|who|does|is|are|can|should|will)\b/i;
  const endsWithQuestion = /\?\s*$/;

  // Повелительные глаголы RU. Конец `(те)?` ловит и «проверь», и «проверьте».
  const imperativeRu = /^(проверь|сделай|настрой|посмотри|добавь|узнай|оптимизируй|создай|выбери|используй|изучи|найди|запусти|установи|включи|отключи|напиши|прочитай|реши|подготовь|разбери|посчитай|измерь|исправь|убери|удали|замени|обнови|внедри|запиши|выдели|сравни|определи|опиши|покажи|объясни|расскажи|перейди|скачай|открой|избегай|избеги|соблюдай|учитывай|планируй|анализируй)(те)?(?![а-яА-Я])/i;
  // Повелительные глаголы EN.
  const imperativeEn = /^(check|make|configure|see|add|learn|optimize|create|choose|use|study|build|fix|find|get|try|install|set|enable|disable|run|start|stop|write|read|measure|calculate|solve|prepare|update|replace|remove|delete|compare|define|describe|show|explain|open|download|follow|review|test|verify|ensure|avoid|prevent|improve|plan|analyze|track|monitor)\b/i;

  const aiFriendlyHeadings = headings.filter(h => {
    const trimmed = h.trim();
    return (
      questionRu.test(trimmed) ||
      questionEn.test(trimmed) ||
      endsWithQuestion.test(trimmed) ||
      imperativeRu.test(trimmed) ||
      imperativeEn.test(trimmed)
    );
  });

  if (aiFriendlyHeadings.length >= 2) {
    score += 3;
    signals.push(tr(lang, 'action-заголовки', 'action headings'));
  } else if (aiFriendlyHeadings.length >= 1) {
    score += 1;
  }

  // 2. Длина параграфов (3 балла) — оптимум 50-200 слов, AI извлекает целиком.
  if (paragraphs.length >= 3) {
    const avgWords = paragraphs.reduce((sum, p) => {
      return sum + p.split(/\s+/).filter(Boolean).length;
    }, 0) / paragraphs.length;

    if (avgWords >= 30 && avgWords <= 150) {
      score += 3;
      signals.push(tr(lang, 'оптимальная длина абзацев', 'optimal paragraph length'));
    } else if (avgWords >= 20 && avgWords <= 200) {
      score += 1;
    }
  }

  // 3. Статистическая плотность (2 балла) — цифры/проценты/даты.
  // AI цитирует конкретику ("$4,500", "73%", "6-8 weeks") охотнее общих утверждений.
  if (totalWords >= 100) {
    const statPatterns = [
      /\b\d{1,3}(?:[.,]\d+)?\s*%/g,                    // проценты
      /[$€₽£¥]\s?\d/g,                                  // валюты
      /\b(19|20)\d{2}\b/g,                             // годы
      /\b\d{1,3}(?:[.,]\d{3})+\b/g,                    // большие числа
      /\b\d+\s*(?:\+|млн|тыс|k|m|million|thousand)\b/gi, // сокращения
    ];
    const statCount = statPatterns.reduce((count, p) => {
      const matches = visibleText.match(p);
      return count + (matches ? matches.length : 0);
    }, 0);

    const statsPer500 = (statCount / totalWords) * 500;
    if (statsPer500 >= 3) {
      score += 2;
      signals.push(tr(lang, 'насыщенная цифрами', 'data-rich'));
    } else if (statsPer500 >= 1) {
      score += 1;
    }
  }

  // 4. Структурные элементы (2 балла) — таблицы и списки.
  const hasTable = /<table\b/i.test(html);
  const listCount = (html.match(/<(ul|ol)\b/gi) || []).length;
  if (hasTable && listCount >= 2) {
    score += 2;
    signals.push(tr(lang, 'таблицы и списки', 'tables and lists'));
  } else if (hasTable || listCount >= 2) {
    score += 1;
  }

  // Нормализуем оценку и формируем сообщение.
  score = Math.min(score, 10);

  if (score >= 7) {
    issues.push({
      severity: 'success',
      title: tr(lang, 'Citability высокая', 'Citability is high'),
      description: signals.length > 0
        ? tr(lang, `Сильные стороны: ${signals.join(', ')}`, `Strengths: ${signals.join(', ')}`)
        : tr(lang, 'AI легко извлекает контент', 'AI can easily extract content'),
    });
  } else if (score >= 4) {
    issues.push({
      severity: 'info',
      title: tr(lang, 'Citability средняя', 'Citability is moderate'),
      description: tr(
        lang,
        'Добавьте question-заголовки и конкретные цифры в тексте',
        'Add question-based headings and specific data points'
      ),
    });
  } else {
    issues.push({
      severity: 'warning',
      title: tr(lang, 'Citability низкая', 'Citability is low'),
      description: tr(
        lang,
        'AI сложно цитировать: длинные абзацы без цифр, общие заголовки',
        'Hard for AI to cite: long paragraphs, vague headings, no data'
      ),
    });
  }

  const maxScore = 10;
  return {
    id: 'citability',
    score,
    maxScore,
    status: toCheckStatus(score, maxScore),
    issues,
  };
}
