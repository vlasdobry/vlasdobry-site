// Проверка E-E-A-T сигналов (Experience, Expertise, Authoritativeness, Trustworthiness).
// Максимум 10 баллов, соответствует весу проверки в виджете vlasdobry.ru.
import type { Issue, CheckResult, Lang } from '../types.js';
import { tr, toCheckStatus } from '../i18n.js';

export function checkEeat(html: string, lang: Lang): CheckResult {
  const issues: Issue[] = [];
  let score = 0;
  const signals: string[] = [];

  // Автор — принимаем только надёжные сигналы: meta-тег, rel=author, Person-схема
  // с непустым name либо HTML-блок class=author. Простое упоминание "author"
  // в JSON-LD статьи даёт ложноположительный результат на placeholder-шаблонах.
  const hasMetaAuthor = /<meta[^>]+name=["']author["'][^>]*content=["']([^"']{2,})["']/i.test(html);
  const hasRelAuthor = /rel=["']author["']/i.test(html);
  const hasPersonSchema = /"@type"\s*:\s*"Person"[^}]*"name"\s*:\s*"[^"]{2,}"/i.test(html);
  const hasAuthorBlock = /class=["'][^"']*author[^"']*["']/i.test(html);

  if (hasMetaAuthor || hasRelAuthor || hasPersonSchema || hasAuthorBlock) {
    score += 3;
    signals.push(tr(lang, 'автор', 'author'));
  }

  // Контакты — email либо телефон в российском (+7/8) или американском (+1) формате.
  const emailPattern = /[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}/;
  const phonePattern = /(\+7|8)[\s-]?\(?\d{3}\)?[\s-]?\d{3}[\s-]?\d{2}[\s-]?\d{2}|\+1[\s-]?\d{3}[\s-]?\d{3}[\s-]?\d{4}/;

  const hasEmail = emailPattern.test(html);
  const hasPhone = phonePattern.test(html);

  if (hasEmail || hasPhone) {
    score += 3;
    signals.push(tr(lang, 'контакты', 'contacts'));
  }

  // Соцсети — ссылки на основные платформы.
  const socialPatterns = [
    /linkedin\.com/i,
    /facebook\.com/i,
    /twitter\.com|x\.com/i,
    /t\.me|telegram/i,
    /instagram\.com/i,
  ];

  const hasSocial = socialPatterns.some((pattern) => pattern.test(html));
  if (hasSocial) {
    score += 3;
    signals.push(tr(lang, 'соцсети', 'social links'));
  }

  // Страница «О нас» / команда / компания.
  const aboutPatterns = [
    /href="[^"]*\/about/i,
    /href="[^"]*\/o-nas/i,
    /href="[^"]*\/company/i,
    /href="[^"]*\/o-kompanii/i,
    /href="[^"]*\/team/i,
  ];

  const hasAboutLink = aboutPatterns.some((pattern) => pattern.test(html));
  if (hasAboutLink) {
    score += 1;
    signals.push(tr(lang, 'о нас', 'about page'));
  }

  if (score >= 9) {
    issues.push({
      severity: 'success',
      title: tr(lang, 'E-E-A-T сигналы сильные', 'E-E-A-T signals are strong'),
      description: tr(lang, `Найдено: ${signals.join(', ')}`, `Found: ${signals.join(', ')}`),
    });
  } else if (score >= 6) {
    issues.push({
      severity: 'info',
      title: tr(lang, 'E-E-A-T сигналы есть', 'E-E-A-T signals are present'),
      description: tr(
        lang,
        `Найдено: ${signals.join(', ')}. Добавьте больше`,
        `Found: ${signals.join(', ')}. Add more signals`,
      ),
    });
  } else if (score >= 3) {
    issues.push({
      severity: 'warning',
      title: tr(lang, 'E-E-A-T сигналы слабые', 'E-E-A-T signals are weak'),
      description:
        signals.length > 0
          ? tr(lang, `Только: ${signals.join(', ')}`, `Only: ${signals.join(', ')}`)
          : tr(lang, 'Добавьте автора, контакты, соцсети', 'Add author data, contacts, and social links'),
    });
  } else {
    issues.push({
      severity: 'critical',
      title: tr(lang, 'E-E-A-T сигналы отсутствуют', 'E-E-A-T signals are missing'),
      description: tr(
        lang,
        'Нет автора, контактов, соцсетей — AI не доверяет',
        'No author, contacts, or social links - AI trust will be low',
      ),
    });
  }

  const maxScore = 10;
  return {
    id: 'eeat',
    score,
    maxScore,
    status: toCheckStatus(score, maxScore),
    issues,
  };
}
