// Rendered-vs-Source check: сравнивает отрендеренный HTML с исходным source HTML,
// определяя зависимость контента от JS (SPA без SSR плохо индексируется AI-ботами).
// Адаптировано из ai-visibility-checker/src/checks/rendered-vs-source.ts под HTML-строки
// (библиотека platform-agnostic — без DOMParser/window, только regex).
// Максимум 5 баллов: нет SPA 5, SPA с хорошим SSR 4, частичный SSR 2, тяжёлый SPA 1.

import type { Issue, CheckResult, Lang } from '../types.js';
import { tr, toCheckStatus } from '../i18n.js';

// Regex-маркеры популярных SPA-фреймворков (React/Vue/Angular/Next/Nuxt).
const SPA_MARKERS: RegExp[] = [
  /\bid\s*=\s*["']root["']/i,
  /\bid\s*=\s*["']app["']/i,
  /\bid\s*=\s*["']__next["']/i,
  /\bid\s*=\s*["']__nuxt["']/i,
  /\bdata-reactroot\b/i,
  /\bng-app\b/i,
  /\bng-version\b/i,
  /\bdata-v-[0-9a-f]+/i,
];

/** Определяет наличие SPA-фреймворка по regex-маркерам. */
export function detectSpa(html: string): boolean {
  return SPA_MARKERS.some(re => re.test(html));
}

/**
 * Извлекает длину видимого текста из HTML-строки.
 * Удаляет script/style, но сохраняет содержимое noscript — это fallback для AI-ботов.
 */
export function extractBodyText(html: string): number {
  if (!html) return 0;

  // Вырезаем только body (если есть), иначе работаем со всей строкой.
  const bodyMatch = html.match(/<body[^>]*>([\s\S]*?)<\/body>/i);
  let content = bodyMatch ? bodyMatch[1] : html;

  // Удаляем script и style целиком (с содержимым).
  content = content.replace(/<script\b[^>]*>[\s\S]*?<\/script>/gi, '');
  content = content.replace(/<style\b[^>]*>[\s\S]*?<\/style>/gi, '');

  // noscript сохраняем — раскрываем теги, оставляя текст внутри.
  content = content.replace(/<\/?noscript[^>]*>/gi, '');

  // Удаляем HTML-комментарии.
  content = content.replace(/<!--[\s\S]*?-->/g, '');

  // Снимаем все остальные теги.
  const text = content.replace(/<[^>]+>/g, ' ');

  // Сворачиваем whitespace и считаем длину.
  return text.replace(/\s+/g, ' ').trim().length;
}

/**
 * Сравнивает rendered HTML с source HTML.
 * Если source недоступен (null) — ставит полный балл (виджет не всегда отдаёт source).
 */
export function checkRenderedVsSource(
  renderedHtml: string,
  sourceHtml: string | null,
  lang: Lang
): CheckResult {
  const issues: Issue[] = [];
  const maxScore = 5;

  // Source не передан — полный балл (виджет не обязан его присылать).
  if (sourceHtml === null) {
    issues.push({
      severity: 'info',
      title: tr(lang, 'Сравнение source недоступно', 'Source comparison unavailable'),
      description: tr(
        lang,
        'Исходный HTML не предоставлен, проверка пропущена',
        'Source HTML was not provided, check skipped',
      ),
    });
    return {
      id: 'renderedVsSource',
      score: maxScore,
      maxScore,
      status: toCheckStatus(maxScore, maxScore),
      issues,
    };
  }

  const isSpa = detectSpa(renderedHtml);
  const renderedLen = extractBodyText(renderedHtml);
  const sourceLen = extractBodyText(sourceHtml);
  const ratio = renderedLen > 0 ? sourceLen / renderedLen : 1;

  let score: number;

  if (!isSpa) {
    // SPA-маркеров нет — контент доступен без JS.
    score = 5;
    issues.push({
      severity: 'success',
      title: tr(lang, 'SPA-фреймворк не обнаружен', 'No SPA framework detected'),
      description: tr(
        lang,
        `Контент доступен без JavaScript (source/rendered: ${Math.round(ratio * 100)}%)`,
        `Content is available without JavaScript (source/rendered: ${Math.round(ratio * 100)}%)`,
      ),
    });
  } else if (sourceLen < 100 && renderedLen > 100) {
    // Почти пустой source, весь контент рендерится через JS — тяжёлый SPA.
    score = 1;
    issues.push({
      severity: 'critical',
      title: tr(lang, 'Тяжёлый SPA без SSR', 'Heavy SPA without SSR'),
      description: tr(
        lang,
        `Source: ${sourceLen} символов, rendered: ${renderedLen}. AI-боты без JS не увидят контент. Нужен SSR или <noscript> fallback`,
        `Source: ${sourceLen} chars, rendered: ${renderedLen}. AI bots without JS see nothing. Implement SSR or <noscript> fallback`,
      ),
    });
  } else if (ratio < 0.5) {
    // Менее половины контента — SSR частичный.
    score = 2;
    issues.push({
      severity: 'warning',
      title: tr(lang, 'SPA с частичным SSR', 'SPA with partial SSR'),
      description: tr(
        lang,
        `В source только ${Math.round(ratio * 100)}% контента. Значительная часть зависит от JS`,
        `Only ${Math.round(ratio * 100)}% of content is in source. Significant JS-dependent content`,
      ),
    });
  } else {
    // SPA есть, но большая часть контента в source — хороший SSR.
    score = 4;
    issues.push({
      severity: 'success',
      title: tr(lang, 'SPA с хорошим SSR', 'SPA with good SSR'),
      description: tr(
        lang,
        `В source ${Math.round(ratio * 100)}% контента — AI-боты получают основной текст без JS`,
        `Source contains ${Math.round(ratio * 100)}% of content — AI bots get main text without JS`,
      ),
    });
  }

  return {
    id: 'renderedVsSource',
    score,
    maxScore,
    status: toCheckStatus(score, maxScore),
    issues,
  };
}
