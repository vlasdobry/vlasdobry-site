// LLM Files check: llms-full.txt (20 баллов) + llms.txt (10 баллов) = 30 баллов.
// llms-full.txt оценивается по длине (главная рекомендация — больше контента AI).
// llms.txt оценивается по структуре (это индексный файл — важна корректность формата).

import type { Issue, CheckResult, ResourceResult, Lang } from '../types.js';
import { tr, toCheckStatus } from '../i18n.js';

// Проверяет структуру llms.txt по спецификации Jeremy Howard (сентябрь 2024):
// H1-заголовок, blockquote-описание, минимум одна H2-секция, минимум N записей
// страниц в формате "- [Title](absoluteURL): description".
// Возвращает количество выполненных критериев и длину.
interface LlmsStructure {
  hasH1: boolean;
  hasBlockquote: boolean;
  h2Count: number;
  pageEntries: number;
  absoluteUrls: boolean;
  length: number;
}

function analyzeLlmsStructure(content: string): LlmsStructure {
  const lines = content.split(/\r?\n/);

  const hasH1 = lines.some(l => /^#\s+\S/.test(l));
  const hasBlockquote = lines.some(l => /^>\s+\S/.test(l));
  const h2Count = lines.filter(l => /^##\s+\S/.test(l)).length;

  const entryLines = lines.filter(l => /^-\s+\[[^\]]+\]\([^)]+\)/.test(l));
  const pageEntries = entryLines.length;

  const urlRegex = /\(([^)]+)\)/;
  const absoluteUrls = entryLines.length > 0 && entryLines.every(l => {
    const match = l.match(urlRegex);
    return match ? /^https?:\/\//.test(match[1]) : false;
  });

  return {
    hasH1,
    hasBlockquote,
    h2Count,
    pageEntries,
    absoluteUrls,
    length: content.length,
  };
}

function scoreLlmFiles(
  llmsTxt: ResourceResult,
  llmsFullTxt: ResourceResult,
  lang: Lang
): { score: number; issues: Issue[] } {
  const issues: Issue[] = [];
  let score = 0;

  if (llmsFullTxt.status === 200 && llmsFullTxt.content) {
    const length = llmsFullTxt.content.length;
    if (length >= 2000) {
      score += 20;
      issues.push({
        severity: 'success',
        title: tr(lang, 'llms-full.txt отличный', 'llms-full.txt is excellent'),
        description: tr(lang, `${length} символов — AI получает полный контент`, `${length} chars - AI gets full context`),
      });
    } else if (length >= 500) {
      score += 12;
      issues.push({
        severity: 'info',
        title: tr(lang, 'llms-full.txt можно расширить', 'llms-full.txt can be expanded'),
        description: tr(lang, `${length} символов. Рекомендуется 2000+`, `${length} chars. Recommended: 2000+`),
      });
    } else {
      score += 5;
      issues.push({
        severity: 'warning',
        title: tr(lang, 'llms-full.txt слишком короткий', 'llms-full.txt is too short'),
        description: tr(lang, `${length} символов. Добавьте больше контента`, `${length} chars. Add more content`),
      });
    }
  } else {
    issues.push({
      severity: 'critical',
      title: tr(lang, 'llms-full.txt отсутствует', 'llms-full.txt is missing'),
      description: tr(lang, 'Главная рекомендация! AI не получает полный контент сайта', 'Main recommendation: AI cannot access the full site content'),
    });
  }

  if (llmsTxt.status === 200 && llmsTxt.content) {
    const struct = analyzeLlmsStructure(llmsTxt.content);

    // Структурные баллы (макс 10): H1 2, blockquote 2, H2 2, ≥5 entries 2, абсолютные URL 2.
    let structScore = 0;
    const missing: string[] = [];

    if (struct.hasH1) structScore += 2;
    else missing.push(tr(lang, 'H1', 'H1 title'));

    if (struct.hasBlockquote) structScore += 2;
    else missing.push(tr(lang, 'описание (blockquote)', 'description (blockquote)'));

    if (struct.h2Count >= 1) structScore += 2;
    else missing.push(tr(lang, 'H2-секции', 'H2 sections'));

    if (struct.pageEntries >= 5) structScore += 2;
    else missing.push(tr(lang, `≥5 ссылок (сейчас ${struct.pageEntries})`, `≥5 entries (current ${struct.pageEntries})`));

    if (struct.absoluteUrls) structScore += 2;
    else if (struct.pageEntries > 0) missing.push(tr(lang, 'абсолютные URL', 'absolute URLs'));

    score += structScore;

    if (structScore >= 8) {
      issues.push({
        severity: 'success',
        title: tr(lang, 'llms.txt корректен', 'llms.txt is well-formed'),
        description: tr(lang, `Структура соответствует спецификации (${struct.length} символов)`, `Structure matches the specification (${struct.length} chars)`),
      });
    } else if (structScore >= 4) {
      issues.push({
        severity: 'info',
        title: tr(lang, 'llms.txt неполный', 'llms.txt is incomplete'),
        description: tr(lang, `Не хватает: ${missing.slice(0, 3).join(', ')}`, `Missing: ${missing.slice(0, 3).join(', ')}`),
      });
    } else {
      issues.push({
        severity: 'warning',
        title: tr(lang, 'llms.txt не по спецификации', 'llms.txt does not match specification'),
        description: tr(lang, `Не хватает: ${missing.slice(0, 3).join(', ')}`, `Missing: ${missing.slice(0, 3).join(', ')}`),
      });
    }
  } else if (llmsFullTxt.status !== 200) {
    issues.push({
      severity: 'warning',
      title: tr(lang, 'llms.txt отсутствует', 'llms.txt is missing'),
      description: tr(lang, 'Базовый файл для AI-систем не найден', 'Base AI discovery file was not found'),
    });
  }

  return { score, issues };
}

export function checkLlmFiles(
  llmsTxt: ResourceResult,
  llmsFullTxt: ResourceResult,
  lang: Lang
): CheckResult {
  const { score, issues } = scoreLlmFiles(llmsTxt, llmsFullTxt, lang);
  const maxScore = 30;

  return {
    id: 'llmFiles',
    score,
    maxScore,
    status: toCheckStatus(score, maxScore),
    issues,
  };
}
