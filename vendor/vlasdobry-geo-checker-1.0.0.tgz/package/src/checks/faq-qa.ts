// Проверка FAQ / Q&A: ищет FAQPage / HowTo в JSON-LD и HTML-паттерны Q&A.
// Адаптировано из src/utils/healthScore/geoScoring.ts (scoreFaqQa) веб-визитки Власа.
// Максимум 15 баллов: FAQPage 7, HowTo 3, HTML Q&A паттерны до 5.

import type { Issue, CheckResult, Lang } from '../types.js';
import { tr, toCheckStatus } from '../i18n.js';

export function checkFaqQa(html: string, jsonLdTypes: string[], lang: Lang): CheckResult {
  const issues: Issue[] = [];
  let score = 0;
  const maxScore = 15;

  // FAQPage в JSON-LD — 7 баллов
  const hasFaqSchema =
    jsonLdTypes.includes('FAQPage') || jsonLdTypes.includes('Question');

  if (hasFaqSchema) {
    score += 7;
    issues.push({
      severity: 'success',
      title: tr(lang, 'FAQPage Schema найден', 'FAQPage schema found'),
      description: tr(
        lang,
        'AI легко извлекает вопросы и ответы',
        'AI can easily extract Q&A content',
      ),
    });
  }

  // HowTo в JSON-LD — 3 балла
  const hasHowTo = jsonLdTypes.includes('HowTo');

  if (hasHowTo) {
    score += 3;
    issues.push({
      severity: 'success',
      title: tr(lang, 'HowTo Schema найден', 'HowTo schema found'),
      description: tr(
        lang,
        'Пошаговые инструкции структурированы',
        'Step-by-step instructions are structured',
      ),
    });
  }

  // HTML Q&A паттерны — до 5 баллов
  // Считаем три типа: <details>/<summary>, <dl>/<dt>, заголовки-вопросы.
  const detailsCount = countMatches(html, /<details[\s>]/gi);
  const summaryCount = countMatches(html, /<summary[\s>]/gi);
  const dlCount = countMatches(html, /<dl[\s>]/gi);
  const dtCount = countMatches(html, /<dt[\s>]/gi);

  // Заголовки, похожие на вопросы (внутри h1-h6)
  const questionHeadingCount = countMatches(
    html,
    /<h[1-6][^>]*>[^<]*\?\s*<\/h[1-6]>/gi,
  );
  // Плюс явные маркеры question/вопрос внутри заголовков
  const questionWordHeadingCount = countMatches(
    html,
    /<h[1-6][^>]*>\s*(?:question|вопрос|q[:\s])/gi,
  );

  const detailsSummary = Math.min(detailsCount, summaryCount);
  const dlDt = dlCount > 0 ? dtCount : 0;
  const patternCount = detailsSummary + dlDt + questionHeadingCount + questionWordHeadingCount;

  if (patternCount >= 3) {
    score += 5;
    issues.push({
      severity: hasFaqSchema ? 'success' : 'info',
      title: tr(lang, 'Q&A контент обнаружен', 'Q&A content detected'),
      description: hasFaqSchema
        ? tr(
            lang,
            'HTML-паттерны Q&A подкрепляют FAQPage Schema',
            'HTML Q&A patterns reinforce FAQPage schema',
          )
        : tr(
            lang,
            'Добавьте FAQPage Schema для лучшей видимости',
            'Add FAQPage schema for better visibility',
          ),
    });
  } else if (patternCount >= 1) {
    score += 2;
    issues.push({
      severity: 'info',
      title: tr(lang, 'Q&A элементы найдены частично', 'Q&A elements partially found'),
      description: tr(
        lang,
        'Расширьте раздел вопросов-ответов и добавьте FAQPage Schema',
        'Expand the Q&A section and add FAQPage schema',
      ),
    });
  } else if (!hasFaqSchema) {
    issues.push({
      severity: 'warning',
      title: tr(lang, 'FAQ/Q&A не найден', 'FAQ/Q&A not found'),
      description: tr(
        lang,
        'Добавьте раздел вопросов-ответов с FAQPage Schema',
        'Add a FAQ section with FAQPage schema',
      ),
    });
  }

  return {
    id: 'faqQa',
    score,
    maxScore,
    status: toCheckStatus(score, maxScore),
    issues,
  };
}

function countMatches(html: string, pattern: RegExp): number {
  const matches = html.match(pattern);
  return matches ? matches.length : 0;
}
