// AI Access check (10 баллов) — проверка доступа критичных AI-ботов через robots.txt.
// Логика:
//   1. Если robots.txt отсутствует (404) — все боты разрешены, полный балл.
//   2. Если robots.txt доступен — парсим секции user-agent и считаем, сколько
//      критичных ботов из `bots` параметра заблокированы.
//   3. Скор = (разрешённые критичные / всего критичных) * 10.
//
// В отличие от виджета vlasdobry.ru (трёхуровневая система tier1/tier2/tier3),
// здесь упрощённая KISS-логика: caller передаёт нужный список ботов через `bots`,
// критичность определяется флагом `critical: true` в BotInfo.

import type { Issue, CheckResult, Lang, ResourceResult, BotInfo } from '../types.js';
import { tr, toCheckStatus } from '../i18n.js';

// Парсит robots.txt на секции user-agent. Возвращает массив пар [агент, директивы].
// Wildcard "*" и явный бот могут идти подряд — каждая секция начинается со строки
// user-agent и заканчивается перед следующей user-agent-директивой.
function parseRobotsSections(content: string): Array<{ agent: string; rules: string }> {
  const lines = content.split(/\r?\n/).map(l => l.trim()).filter(Boolean);
  const sections: Array<{ agent: string; rules: string }> = [];
  let currentAgents: string[] = [];
  let currentRules: string[] = [];

  const flush = () => {
    if (currentAgents.length > 0) {
      const joined = currentRules.join('\n').toLowerCase();
      for (const agent of currentAgents) {
        sections.push({ agent, rules: joined });
      }
    }
    currentAgents = [];
    currentRules = [];
  };

  for (const line of lines) {
    const lower = line.toLowerCase();
    if (lower.startsWith('user-agent:')) {
      if (currentRules.length > 0) {
        flush();
      }
      currentAgents.push(lower.slice('user-agent:'.length).trim());
    } else if (currentAgents.length > 0) {
      currentRules.push(line);
    }
  }
  flush();

  return sections;
}

// Заблокирован ли бот? Сначала ищем явную секцию для него, потом — wildcard.
// Учитываем Allow — если есть Allow после Disallow:/, значит сайт не полностью
// закрыт (частичная блокировка не считается full block).
function isBotBlocked(content: string, bot: string): boolean {
  const botLower = bot.toLowerCase();
  const sections = parseRobotsSections(content);

  const botSections = sections.filter(s => s.agent === botLower);
  if (botSections.length > 0) {
    return botSections.some(s => {
      return /disallow:\s*\/\s*$/m.test(s.rules) && !/^allow:\s*\//m.test(s.rules);
    });
  }

  const wildcardSections = sections.filter(s => s.agent === '*');
  return wildcardSections.some(s => {
    return /disallow:\s*\/\s*$/m.test(s.rules) && !/^allow:\s*\//m.test(s.rules);
  });
}

export function checkAiAccess(
  robotsTxt: ResourceResult,
  bots: BotInfo[],
  lang: Lang
): CheckResult {
  const issues: Issue[] = [];
  const maxScore = 10;

  // 404 или отсутствие контента → robots.txt нет, все боты разрешены.
  if (robotsTxt.status === 404 || robotsTxt.status !== 200 || !robotsTxt.content) {
    issues.push({
      severity: 'success',
      title: tr(lang, 'AI-боты разрешены', 'AI bots are allowed'),
      description: tr(
        lang,
        'Нет robots.txt — все боты могут индексировать',
        'No robots.txt - all bots can index'
      ),
    });
    return {
      id: 'aiAccess',
      score: maxScore,
      maxScore,
      status: toCheckStatus(maxScore, maxScore),
      issues,
    };
  }

  const content = robotsTxt.content;
  const criticalBots = bots.filter(b => b.critical);

  // Если критичных ботов не передали — считаем по всем ботам.
  // Если и ботов нет — полный балл (нечего проверять).
  const botsToCheck = criticalBots.length > 0 ? criticalBots : bots;
  if (botsToCheck.length === 0) {
    issues.push({
      severity: 'success',
      title: tr(lang, 'AI-боты разрешены', 'AI bots are allowed'),
      description: tr(lang, 'Список ботов пуст', 'Bots list is empty'),
    });
    return {
      id: 'aiAccess',
      score: maxScore,
      maxScore,
      status: toCheckStatus(maxScore, maxScore),
      issues,
    };
  }

  const blocked: string[] = [];
  const allowed: string[] = [];
  for (const bot of botsToCheck) {
    if (isBotBlocked(content, bot.name)) {
      blocked.push(bot.name);
    } else {
      allowed.push(bot.name);
    }
  }

  const total = botsToCheck.length;
  const score = Math.round((allowed.length / total) * maxScore);

  if (blocked.length === 0) {
    issues.push({
      severity: 'success',
      title: tr(lang, 'AI-боты разрешены', 'AI bots are allowed'),
      description: tr(
        lang,
        `Все ${total} проверенных AI-систем могут индексировать`,
        `All ${total} checked AI systems can index this site`
      ),
    });
  } else {
    const preview = blocked.slice(0, 3).join(', ') + (blocked.length > 3 ? '…' : '');
    const severity: Issue['severity'] = score === 0 ? 'critical' : 'warning';
    issues.push({
      severity,
      title: tr(
        lang,
        `${blocked.length} AI-бот(а) заблокированы`,
        `${blocked.length} AI bot(s) blocked`
      ),
      description: preview,
    });
  }

  return {
    id: 'aiAccess',
    score,
    maxScore,
    status: toCheckStatus(score, maxScore),
    issues,
  };
}
