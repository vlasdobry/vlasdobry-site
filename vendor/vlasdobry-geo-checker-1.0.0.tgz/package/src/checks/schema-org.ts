// Schema.org проверка (20 баллов).
// Парсит все <script type="application/ld+json"> блоки из HTML,
// рекурсивно собирает все @type (включая @graph, массивы, вложенные сущности
// такие как provider, mainEntity, author, itemListElement и т.д.).
// Битые блоки молча игнорируются — один невалидный JSON не обнуляет оценку,
// но если ни один блок не распарсился — ставим fail.

import type { Issue, CheckResult, Lang } from '../types.js';
import { tr, toCheckStatus } from '../i18n.js';

const SCRIPT_RE = /<script\b[^>]*type=["']application\/ld\+json["'][^>]*>([\s\S]*?)<\/script>/gi;

const MAX_SCORE = 20;
const BASE_SCORE = 8;

// Вес типов: основные сущности — 4, Q&A — 3, HowTo — 2, вспомогательные — 1
const TYPE_WEIGHTS: Record<string, number> = {
  // Identity / Content — 4 балла
  Organization: 4,
  LocalBusiness: 4,
  ProfessionalService: 4,
  MedicalBusiness: 4,
  Hotel: 4,
  Restaurant: 4,
  Store: 4,
  Person: 4,
  Article: 4,
  BlogPosting: 4,
  NewsArticle: 4,
  // Structured Q&A — 3 балла
  FAQPage: 3,
  QAPage: 3,
  // HowTo — 2 балла
  HowTo: 2,
  // Supporting — 1 балл
  WebSite: 1,
  WebPage: 1,
  Product: 1,
  Offer: 1,
  Service: 1,
  BreadcrumbList: 1,
};

export function checkSchemaOrg(html: string, lang: Lang): CheckResult {
  const issues: Issue[] = [];

  // Быстрая проверка наличия JSON-LD блоков
  const hasAnyBlock = /<script\b[^>]*type=["']application\/ld\+json["']/i.test(html);

  if (!hasAnyBlock) {
    issues.push({
      severity: 'critical',
      title: tr(lang, 'Schema.org отсутствует', 'Schema.org is missing'),
      description: tr(
        lang,
        'Добавьте JSON-LD разметку для AI',
        'Add JSON-LD structured data for AI systems',
      ),
    });
    return {
      id: 'schemaOrg',
      score: 0,
      maxScore: MAX_SCORE,
      status: toCheckStatus(0, MAX_SCORE),
      issues,
    };
  }

  const types = extractAllTypes(html);

  if (types.length === 0) {
    // Блоки есть, но ни один не распарсился
    issues.push({
      severity: 'critical',
      title: tr(lang, 'Schema.org битый', 'Schema.org is broken'),
      description: tr(
        lang,
        'JSON-LD блоки найдены, но не распарсились — проверьте валидность JSON',
        'JSON-LD blocks found but failed to parse - check JSON validity',
      ),
    });
    return {
      id: 'schemaOrg',
      score: 0,
      maxScore: MAX_SCORE,
      status: toCheckStatus(0, MAX_SCORE),
      issues,
    };
  }

  // Есть валидный JSON-LD — базовые 8 баллов + вес каждого найденного типа
  let score = BASE_SCORE;
  const scoredTypes: string[] = [];
  for (const t of types) {
    const weight = TYPE_WEIGHTS[t];
    if (weight) {
      score += weight;
      scoredTypes.push(t);
    }
  }
  if (score > MAX_SCORE) score = MAX_SCORE;

  // Обратная связь: сколько известных типов найдено
  if (scoredTypes.length >= 3) {
    issues.push({
      severity: 'success',
      title: tr(
        lang,
        `Schema.org: ${scoredTypes.length} типов`,
        `Schema.org: ${scoredTypes.length} types`,
      ),
      description: tr(
        lang,
        `${scoredTypes.slice(0, 3).join(', ')} — отлично для AI`,
        `${scoredTypes.slice(0, 3).join(', ')} - great for AI`,
      ),
    });
  } else if (scoredTypes.length === 2) {
    issues.push({
      severity: 'info',
      title: tr(lang, 'Schema.org: 2 типа', 'Schema.org: 2 types'),
      description: tr(
        lang,
        `${scoredTypes.join(', ')}. Добавьте ещё типы`,
        `${scoredTypes.join(', ')}. Add more types`,
      ),
    });
  } else if (scoredTypes.length === 1) {
    issues.push({
      severity: 'warning',
      title: tr(lang, 'Schema.org: 1 тип', 'Schema.org: 1 type'),
      description: tr(
        lang,
        `${scoredTypes[0]}. Рекомендуется 3+ типа`,
        `${scoredTypes[0]}. Recommended: 3+ types`,
      ),
    });
  } else {
    // JSON-LD валиден, но ключевые типы не распознаны
    issues.push({
      severity: 'warning',
      title: tr(lang, 'Schema.org неполный', 'Schema.org is incomplete'),
      description: tr(
        lang,
        'JSON-LD есть, но ключевые типы не распознаны',
        'JSON-LD exists, but key types were not recognized',
      ),
    });
  }

  return {
    id: 'schemaOrg',
    score,
    maxScore: MAX_SCORE,
    status: toCheckStatus(score, MAX_SCORE),
    issues,
  };
}

// Парсит все JSON-LD блоки, рекурсивно собирает @type из всей структуры
function extractAllTypes(html: string): string[] {
  const types = new Set<string>();
  const matches = html.matchAll(SCRIPT_RE);

  for (const match of matches) {
    const raw = match[1]?.trim();
    if (!raw) continue;

    let parsed: unknown;
    try {
      parsed = JSON.parse(raw);
    } catch {
      continue;
    }

    collectTypes(parsed, types);
  }

  return [...types];
}

// Рекурсивно обходит структуру: массивы, @graph и ВСЕ вложенные объекты
// (provider, mainEntity, author, publisher, itemListElement и т.д.)
function collectTypes(node: unknown, acc: Set<string>): void {
  if (!node) return;

  if (Array.isArray(node)) {
    for (const item of node) {
      collectTypes(item, acc);
    }
    return;
  }

  if (typeof node !== 'object') return;

  const obj = node as Record<string, unknown>;

  // @type: строка или массив строк
  const type = obj['@type'];
  if (typeof type === 'string') {
    acc.add(type);
  } else if (Array.isArray(type)) {
    for (const t of type) {
      if (typeof t === 'string') acc.add(t);
    }
  }

  // Рекурсия по ВСЕМ значениям (включая @graph) — пропускаем только служебные поля
  for (const key of Object.keys(obj)) {
    if (key === '@type' || key === '@context' || key === '@id') continue;
    const value = obj[key];
    if (value && typeof value === 'object') {
      collectTypes(value, acc);
    }
  }
}
