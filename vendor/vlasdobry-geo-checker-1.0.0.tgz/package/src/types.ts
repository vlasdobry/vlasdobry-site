// Публичные типы библиотеки @vlasdobry/geo-checker

export type Lang = 'ru' | 'en';

// Идентификаторы 7 проверок
export type CheckId =
  | 'llmFiles'
  | 'schemaOrg'
  | 'faqQa'
  | 'eeat'
  | 'citability'
  | 'aiAccess'
  | 'renderedVsSource';

// Уровни серьёзности issue (4 уровня для детализации)
export type Severity = 'critical' | 'warning' | 'info' | 'success';

// Статус проверки (3 уровня для UI)
export type CheckStatus = 'pass' | 'warn' | 'fail';

// Пункт обратной связи — может быть как проблемой, так и подтверждением успеха
export interface Issue {
  severity: Severity;
  title: string;
  description: string;
}

// Результат одной проверки — структурированный, унифицированный между виджетом и extension
export interface CheckResult {
  id: CheckId;
  score: number;
  maxScore: number;
  status: CheckStatus;
  issues: Issue[];
}

// Информация о ресурсе (fetch результат), который проверяется
export interface ResourceResult {
  url?: string;
  status: number;
  content: string | null;
  error?: string | null;
  headers?: Record<string, string>;
}

// AI-бот для проверки доступа
export interface BotInfo {
  name: string;
  vendor: string;
  purpose: 'search' | 'training' | 'user-browse';
  critical: boolean;
}

// Финальный скор
export type ScoreLevel = 'critical' | 'warning' | 'good' | 'excellent';

export interface GeoScore {
  total: number;
  maxTotal: number;
  status: ScoreLevel;
  statusLabel: string;
  breakdown: Record<CheckId, number>;
  checks: CheckResult[];
  issues: Issue[]; // объединённые из всех проверок, отсортированы по severity
}

// Входные данные для calculateGeoScore
export interface GeoScoreInput {
  /** Pre-JS HTML — что видят AI-краулеры. Используется для всех content-проверок (schema, eeat, faq, citability). */
  homepage: ResourceResult;
  llmsTxt: ResourceResult;
  llmsFullTxt: ResourceResult;
  robotsTxt: ResourceResult;
  /** Post-JS rendered HTML (опционально). Используется только для rendered-vs-source сравнения.
   *  Если не передано — проверка даёт полный балл (нет возможности сравнить). */
  renderedHtml?: string | null;
}

export interface GeoScoreOptions {
  lang?: Lang;
  bots?: BotInfo[]; // если не указан — используется встроенный список
}

// Веса проверок (100 баллов)
export const DEFAULT_WEIGHTS: Record<CheckId, number> = {
  llmFiles: 30,
  schemaOrg: 20,
  faqQa: 15,
  eeat: 10,
  citability: 10,
  aiAccess: 10,
  renderedVsSource: 5,
};

// Встроенный список критичных AI-ботов (если caller не передал свой)
export const DEFAULT_BOTS: BotInfo[] = [
  { name: 'GPTBot', vendor: 'OpenAI', purpose: 'training', critical: true },
  { name: 'OAI-SearchBot', vendor: 'OpenAI', purpose: 'search', critical: true },
  { name: 'ChatGPT-User', vendor: 'OpenAI', purpose: 'user-browse', critical: false },
  { name: 'PerplexityBot', vendor: 'Perplexity', purpose: 'search', critical: true },
  { name: 'Perplexity-User', vendor: 'Perplexity', purpose: 'user-browse', critical: false },
  { name: 'Google-Extended', vendor: 'Google', purpose: 'training', critical: true },
  { name: 'ClaudeBot', vendor: 'Anthropic', purpose: 'training', critical: true },
  { name: 'YandexComBot', vendor: 'Yandex', purpose: 'search', critical: true },
];
