// Публичный API @vlasdobry/geo-checker

export type {
  Lang,
  CheckId,
  Severity,
  CheckStatus,
  Issue,
  CheckResult,
  ResourceResult,
  BotInfo,
  ScoreLevel,
  GeoScore,
  GeoScoreInput,
  GeoScoreOptions,
} from './types.js';

export { DEFAULT_BOTS, DEFAULT_WEIGHTS } from './types.js';

// Индивидуальные проверки — можно вызывать по отдельности
export { checkLlmFiles } from './checks/llm-files.js';
export { checkSchemaOrg } from './checks/schema-org.js';
export { checkFaqQa } from './checks/faq-qa.js';
export { checkEeat } from './checks/eeat.js';
export { checkCitability } from './checks/citability.js';
export { checkAiAccess } from './checks/ai-access.js';
export { checkRenderedVsSource } from './checks/rendered-vs-source.js';

// Агрегатор — рекомендуемый способ использования
export { calculateGeoScore } from './scoring.js';
