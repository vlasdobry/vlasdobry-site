# @vlasdobry/geo-checker

Shared GEO audit library. Used by:
- **Widget** on vlasdobry.ru (Health Score diagnostics)
- **Extension** AI Visibility Checker (Chrome Web Store)

## 7 проверок (100 баллов)

| Проверка | Вес | Что делает |
|---|---|---|
| llmFiles | 30 | llms.txt структура + llms-full.txt длина |
| schemaOrg | 20 | JSON-LD типы с рекурсией по вложенным entities |
| faqQa | 15 | FAQPage, HowTo schema, HTML Q&A patterns |
| eeat | 10 | author, contacts, social, about page |
| citability | 10 | длина абзацев, вопросы-заголовки, статистика |
| aiAccess | 10 | robots.txt доступ для AI-ботов |
| renderedVsSource | 5 | SPA detection + content ratio |

## API

```ts
import { calculateGeoScore, checkSchemaOrg, ... } from '@vlasdobry/geo-checker';

const score = calculateGeoScore({
  homepage: { content: html, status: 200 },
  llmsTxt: { content: ..., status: 200 },
  llmsFullTxt: { content: ..., status: 200 },
  robotsTxt: { content: ..., status: 200 },
  sourceHtml: rawHtml, // для renderedVsSource
}, { lang: 'ru', bots: [...] });
```

## Принципы

- **Платформо-агностично** — никаких chrome.*, window.*, fetch
- **Вход** — HTML-строки (DOMParser внутри где нужен)
- **Выход** — структурированный `CheckResult` с `issues[]`
- **Тестируемо** — чистые функции, vitest
